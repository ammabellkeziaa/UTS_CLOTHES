<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, sizeization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];
$request = [];

if (isset($_SERVER['PATH_INFO'])) {
    $request = explode('/', trim($_SERVER['PATH_INFO'], '/'));
}

function getConnection()
{
    $host = 'localhost';
    $db   = 'clothes';
    $user = 'root';
    $pass = ''; // Ganti dengan password MySQL Anda jika ada
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        return new PDO($dsn, $user, $pass, $options);
    } catch (\PDOException $e) {
        throw new \PDOException($e->getMessage(), (int)$e->getCode());
    }
}

function response($status, $data = NULL)
{
    header("HTTP/1.1 " . $status);
    if ($data) {
        echo json_encode($data);
    }
    exit();
}

$db = getConnection();

switch ($method) {
    case 'GET':
        if (!empty($request) && isset($request[0])) {
            $id = $request[0];
            $stmt = $db->prepare("SELECT * FROM clothes WHERE id = ?");
            $stmt->execute([$id]);
            $clothes = $stmt->fetch();
            if ($clothes) {
                response(200, $clothes);
            } else {
                response(404, ["message" => "clothes not found"]);
            }
        } else {
            $stmt = $db->query("SELECT * FROM clothes");
            $clothess = $stmt->fetchAll();
            response(200, $clothess);
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        if (!isset($data->name) || !isset($data->size) || !isset($data->prize) || !isset($data->stok)) {
            response(400, ["message" => "Missing required fields"]);
        }
        $sql = "INSERT INTO clothes (name, size, prize, stok) VALUES (?, ?, ?, ?)";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->size, $data->prize, $data->stok])) {
            response(201, ["message" => "clothes created", "id" => $db->lastInsertId()]);
        } else {
            response(500, ["message" => "Failed to create clothes"]);
        }
        break;

    case 'PUT':
        if (empty($request) || !isset($request[0])) {
            response(400, ["message" => "clothes ID is required"]);
        }
        $id = $request[0];
        $data = json_decode(file_get_contents("php://input"));
        if (!isset($data->name) || !isset($data->size) || !isset($data->prize) || !isset($data->stok)) {
            response(400, ["message" => "Missing required fields"]);
        }
        $sql = "UPDATE clothes SET name = ?, size = ?, prize = ?, stok = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$data->name, $data->size, $data->prize, $data->stok, $id])) {
            response(200, ["message" => "clothes updated"]);
        } else {
            response(500, ["message" => "Failed to update clothes"]);
        }
        break;

    case 'DELETE':
        if (empty($request) || !isset($request[0])) {
            response(400, ["message" => "clothes ID is required"]);
        }
        $id = $request[0];
        $sql = "DELETE FROM clothes WHERE id = ?";
        $stmt = $db->prepare($sql);
        if ($stmt->execute([$id])) {
            response(200, ["message" => "clothes deleted"]);
        } else {
            response(500, ["message" => "Failed to delete clothes"]);
        }
        break;

    default:
        response(405, ["message" => "Method not allowed"]);
        break;
}
